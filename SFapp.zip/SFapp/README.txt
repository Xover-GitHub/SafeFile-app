SafeFile app -> Run with Administrator mode only
SafeFile app -> Turn off your antivirus, if it deletes app, or blocks it